# EcoSchool Water AI – Dashboard demo

Dashboard demo cho hệ thống tái chế nước xám + tưới thông minh (React + Tailwind, chạy bằng CDN, **không cần build**).

## Cấu trúc
- `index.html` – toàn bộ ứng dụng (một file).
- `vercel.json`, `netlify.toml`, `.github/workflows/pages.yml` – cấu hình deploy.

## Chạy thử trên máy
Mở thẳng `index.html` bằng trình duyệt, hoặc:
```bash
npx serve .
```

## Deploy
### Vercel (nhanh nhất)
1. Đẩy repo lên GitHub.
2. vercel.com → **Add New… → Project** → chọn repo → Framework Preset: **Other** → **Deploy**.
   (Không cần Build Command, Output Directory để trống.)

### GitHub Pages
1. Repo → **Settings → Pages → Source: GitHub Actions**.
2. Push lên nhánh `main`, workflow tự deploy.
   Link: `https://<username>.github.io/<repo>/`

### Netlify
Kéo thả thư mục vào app.netlify.com/drop, hoặc kết nối repo (Publish directory: `.`).

## Chỉnh số liệu
Tìm khối `CONFIG` và `DEFAULTS` gần đầu thẻ `<script>` trong `index.html`.
